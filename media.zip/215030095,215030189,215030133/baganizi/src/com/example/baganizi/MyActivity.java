package com.example.baganizi;

import android.app.Activity;
import android.os.Bundle;
import android.view.*;
import android.widget.Button;
import android.widget.TextView;

import static com.example.baganizi.R.id.button;

public class MyActivity extends Activity {

    TextView Ctxt;
    /**
     * Called when the activity is first created.
     */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        Ctxt=(TextView) findViewById(R.id.TX_1);
        registerForContextMenu(Ctxt);



TextView TX1=(TextView) findViewById(R.id.TX_1);
        Button btnclose = (Button) findViewById(button);


       btnclose.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {

               // TODO Auto-generated method stub
               finish();
               System.exit(0);
           }
       });


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        switch (item.getItemId())
        {
            case R.id.button:
            finish();
            System.exit(0);
            default:
                return super.onOptionsItemSelected(item);
        }


    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v,ContextMenu.ContextMenuInfo menuInfo) {

        super.onCreateContextMenu(menu, v, menuInfo);

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu ,menu);

    }



    @Override
    public boolean onContextItemSelected(MenuItem item)
    {
        switch (item.getItemId())
        {
            case button:
            finish();
            System.exit(0);
            default:
                return super.onContextItemSelected(item);
        }}


}
